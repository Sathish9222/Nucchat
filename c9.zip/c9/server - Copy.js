var express = require('express');
var bodyParser = require('body-parser');
var request = require('request');


var app = express();


const SendOtp = require('sendotp');

var port = process.env.PORT || 3000;
var ip = process.env.IP || "127.0.0.1";

app.use(bodyParser.urlencoded({ extended: false}));
app.use(bodyParser.json());

app.post('/', function(req,res) 
{ 
    console.log(req.body) 
    var mobile; 
    if(req.body.result.action == "loanamount") 
    {
         mobile = req.body.result.parameters.mobile;
         if(mobile) { 
        console.log("Numbersend"); const sendOtp = new SendOtp('185631AmOLMgsR5a1bd872'); 
        sendOtp.send("919790998945", "PRIIND", function (error, data, response)
         { 
             res.json({ "speech": "Enter OTP ", "displayText": "Enter OTP " }) 
            }); } } 
            else if(req.body.result.action == "otp") 
            { var mobilenum = req.body.result.parameters.number;
                 if(mobilenum) { console.log("Numbersend" + mobile);
                  const sendOtp = new SendOtp('185631AmOLMgsR5a1bd872');
                   sendOtp.verify("919790998945", mobilenum, function (error, data, response)
                    { console.log(data); // data object with keys 'message' and 'type' 
                    if(data.type == 'success'){
                         res.json({ "speech": "OTP verified successfully ", "displayText": "OTP verified successfully "
                         }) 
                        } 
                          if(data.type == 'error')
                          {
                               res.json({ "speech": "OTP verification failed ", 
                                         "displayText": "OTP verification failed " 
                        }) 
} 
 });
 }}
    else if(req.body.result.action == "Status") { 
        var postData =JSON.stringify({"dateOfBirth":null,"loanAccountNumber":null,"primaryCustomerOnly":false,"requestChannel":"MSERV","identificationTypeId":null,"requestHeader":{"userDetail":{"branchId":5,"userCode":"SYSTEM"},"tenantId":505},"mobileNumber":"7171717171","identificationNumber":null,"loanId":5000291});
        request.post({ headers: {'content-type' : 'application/json'}, url: 'http://10.1.60.164:9696/finnone-LMS/lms/customerService/getLoans', body: postData },
        function(error, response, body)
        {
           
             if(response.statusCode == 200){
        var val = JSON.parse(body);
       var loanAcNo = val.success[0].loanDetails[0].loanStatus;

       if(loanAcNo=="A")
       {
           loanAcNo="Active";
       }
       else
       {
           loanAcNo="In Progress";
       }

var Overdue = val.success[0].loanDetails[0].amountOverdue;


        
          res.json({
            "speech": loanAcNo,
            "displayText": loanAcNo
        })
             }

});  }  
    
    else if(req.body.result.action == "overdue") { 
        
       var postData =JSON.stringify({"dateOfBirth":null,"loanAccountNumber":null,"primaryCustomerOnly":false,"requestChannel":"MSERV","identificationTypeId":null,"requestHeader":{"userDetail":{"branchId":5,"userCode":"SYSTEM"},"tenantId":505},"mobileNumber":"7171717171","identificationNumber":null,"loanId":5000291});
        request.post({ headers: {'content-type' : 'application/json'}, url: 'http://10.1.60.164:9696/finnone-LMS/lms/customerService/getLoans', body: postData },
        function(error, response, body)
        {
            if(response.statusCode == 200){

            
        var val = JSON.parse(body);
       var loanAcNo = val.success[0].customerNumber;

var Overdue = val.success[0].loanDetails[0].amountOverdue;

        
        
          res.json({
            "speech": Overdue,
            "displayText": Overdue
        })
}
});  
        
    }
    
});  app.listen(port, ip);